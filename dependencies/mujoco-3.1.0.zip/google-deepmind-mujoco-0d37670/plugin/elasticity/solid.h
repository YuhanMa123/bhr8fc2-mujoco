// Copyright 2022 DeepMind Technologies Limited
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef MUJOCO_PLUGIN_ELASTICITY_SOLID_H_
#define MUJOCO_PLUGIN_ELASTICITY_SOLID_H_

#include <optional>
#include <vector>

#include <mujoco/mjdata.h>
#include <mujoco/mjmodel.h>
#include <mujoco/mjtnum.h>
#include "elasticity.h"


namespace mujoco::plugin::elasticity {

class Solid {
 public:
  // Returns a new Solid instance or nullopt on failure.
  static std::optional<Solid> Create(const mjModel* m, mjData* d, int instance);
  Solid(Solid&&) = default;

  Solid& operator=(Solid&& other) = default;

  void Compute(const mjModel* m, mjData* d, int instance);

  static void RegisterPlugin();

  int f0;  // index of corresponding flex
  int i0;  // index of first body
  int nc;  // number of cubes in the grid
  int nv;  // number of vertices (bodies) in the solid
  int nt;  // number of volumetric elements (tetrahedra)
  int ne;  // number of edges in the solid

  // connectivity info for mapping tetrahedra to edges and vertices
  std::vector<Stencil3D> elements;          // 4 vertices and 6 edges (nt x 10)
  std::vector<std::pair<int, int> > edges;  // edge to vertex map     (ne x 2)

  // precomputed quantities
  std::vector<mjtNum> metric;               // geom-induced metric    (nt x 36)
  std::vector<mjtNum> reference;            // reference lengths      (ne x 1)
  std::vector<mjtNum> deformed;             // deformed lengths       (ne x 1)
  std::vector<mjtNum> previous;             // previous-step lengths  (ne x 1)
  std::vector<mjtNum> elongation;           // edge elongation        (ne x 1)

  mjtNum damping;

 private:
  Solid(const mjModel* m, mjData* d, int instance, mjtNum nu, mjtNum E,
        mjtNum damp, const std::vector<int>& simplex,
        const std::vector<int>& edgeidx);
};

}  // namespace mujoco::plugin::elasticity

#endif  // MUJOCO_PLUGIN_ELASTICITY_SOLID_H_
